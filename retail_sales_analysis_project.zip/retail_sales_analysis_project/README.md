# Retail Sales Data Analysis

A beginner-friendly portfolio project exploring sales, revenue, estimated profit, product categories, regions, and payment methods with Python, Pandas, SQL, and Excel/Power BI-ready data.

> **Dataset:** Synthetic sample data created for practice. It does not represent a real company or real customer transactions.

## Business Questions
1. What are total revenue, estimated cost, and estimated profit?
2. Which categories generate the most revenue?
3. Which regions perform best?
4. How does revenue change month to month?
5. Which payment methods are most common?
6. What data-quality issues need to be addressed?

## Tools
- Python, Pandas, NumPy
- Matplotlib
- SQL
- Excel or Power BI (optional extension)

## Repository Structure
```text
retail-sales-analysis/
├── data/retail_sales.csv
├── notebooks/retail_sales_analysis.ipynb
├── sql/analysis_queries.sql
├── images/                  # Add dashboard screenshots here
├── requirements.txt
└── README.md
```

## How to Run
1. Install Python 3.10 or later.
2. Download or clone this repository.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Open `notebooks/retail_sales_analysis.ipynb` in Jupyter Notebook or VS Code.
5. Run the cells from top to bottom.

## Analysis Workflow
1. Load and inspect the CSV.
2. Check missing values and duplicate records.
3. Remove exact duplicate rows and fill missing categories with `Unknown`.
4. Create monthly summaries.
5. Compare category and regional performance.
6. Visualize trends and write recommendations supported by the results.

## Metrics
- **Revenue:** sales value after discount.
- **Estimated cost:** simulated product cost.
- **Estimated profit:** revenue minus estimated cost.
- **Profit margin:** estimated profit divided by revenue.

Because costs are simulated, profit figures are illustrative rather than audited financial results.

## Findings
Run the notebook to calculate actual results and use the tables/charts to write 3–5 evidence-based findings. Do not add unverified claims.

## Data Dictionary
| Column | Description |
|---|---|
| `order_id` | Sample order identifier; one duplicate row is intentionally included |
| `order_date` | Order date |
| `region` | Sales region |
| `category` | Product category |
| `product` | Product name |
| `quantity` | Units sold |
| `unit_price` | Unit price before discount |
| `discount_pct` | Discount percentage |
| `revenue` | Sales value after discount |
| `estimated_cost` | Simulated cost estimate |
| `profit` | Revenue minus estimated cost |
| `payment_method` | Sample payment method |

## Future Improvements
- Build an interactive Power BI dashboard.
- Add KPI cards for Revenue, Profit, Orders, and Profit Margin.
- Add slicers for month, region, and category.
- Save dashboard screenshots in `images/`.

## Author
Sagar Gupta
