-- Retail Sales Analysis: example SQL queries
-- Load data into a table named retail_sales before running these.

-- 1. Overall KPIs
SELECT SUM(revenue) AS total_revenue,
       SUM(estimated_cost) AS total_estimated_cost,
       SUM(profit) AS total_profit,
       COUNT(DISTINCT order_id) AS distinct_orders,
       SUM(profit) * 1.0 / NULLIF(SUM(revenue), 0) AS profit_margin
FROM retail_sales;

-- 2. Performance by category
SELECT category, SUM(revenue) AS total_revenue,
       SUM(profit) AS total_profit, SUM(quantity) AS units_sold
FROM retail_sales
GROUP BY category
ORDER BY total_revenue DESC;

-- 3. Regional performance
SELECT region, SUM(revenue) AS total_revenue, SUM(profit) AS total_profit
FROM retail_sales
GROUP BY region
ORDER BY total_revenue DESC;

-- 4. Monthly trend (date syntax can vary by SQL database)
SELECT SUBSTRING(order_date, 1, 7) AS order_month,
       SUM(revenue) AS monthly_revenue, SUM(profit) AS monthly_profit
FROM retail_sales
GROUP BY SUBSTRING(order_date, 1, 7)
ORDER BY order_month;

-- 5. Duplicate order IDs
SELECT order_id, COUNT(*) AS row_count
FROM retail_sales
GROUP BY order_id
HAVING COUNT(*) > 1;

-- 6. Missing categorical values
SELECT SUM(CASE WHEN region IS NULL THEN 1 ELSE 0 END) AS missing_region,
       SUM(CASE WHEN payment_method IS NULL THEN 1 ELSE 0 END) AS missing_payment_method
FROM retail_sales;
